package main

import (
	"encoding/csv"
	"fmt"
	"io"
	"log"
	"math"
	"os"
	"strconv"
	"sync"
	"time"

	icarus "git.ironzone.ace/icarus/icarusClient"
)

// const (
// 	defaultCert string = `-----BEGIN CERTIFICATE-----
// MIIC9TCCAd2gAwIBAgIRAKRQOLvrvmORBJxJKkhCpWgwDQYJKoZIhvcNAQELBQAw
// EjEQMA4GA1UEChMHQWNtZSBDbzAeFw0xOTAxMDkxNzQ1NTdaFw0yMDAxMDkxNzQ1
// NTdaMBIxEDAOBgNVBAoTB0FjbWUgQ28wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAw
// ggEKAoIBAQDGzdsktG2DGiQEt7ce1sWlcSc1QNbpLcRemcrGxJKw2JeWYY42R5Le
// +umtLV/xy0+ZIA47iHETj0IFFYjWdixmz5/yHnnnJbz8uKinbk3eTmaR6y+EwSAp
// gFjXFYjRgif4wPk0qnkgHaI+TJXn2dbBnpv0cX34aUKwaCa/qh0XEZ2nqmjjeowx
// mqpD4etICnaMKdJg2Z+da/YG8ExFnwYpzNS9QdfujAxHJ7DoMhPZnyc/sCmaBq+X
// eAZbMHtWFuv/24lA/KyJBmCEQGp2x9tn+HmM89SQOj1yOwOqZB87+rjENhp87rgh
// MD4vB93/Mzk48tC1LYlr7cLoBh22tskRAgMBAAGjRjBEMA4GA1UdDwEB/wQEAwIF
// oDATBgNVHSUEDDAKBggrBgEFBQcDATAMBgNVHRMBAf8EAjAAMA8GA1UdEQQIMAaH
// BH8AAAEwDQYJKoZIhvcNAQELBQADggEBAKYVTX6fzjOU63QxdtSs9Ot6GdAqaknQ
// baTiRnAsXJuRCDZpRIEQKFECC7tdEBbyCh5FiyjpVqxn+U2/OcdNHPYxdHRevRWM
// vmNqxeOjha62Bp/JKoN0WR/NfZ7oSHFQYm5kGxTSt6n/BKovWOHI4je0PHD/YITt
// Xw5IgIEPDS2eecE+jrHBU596X1jeHSuk+XdQ9Hmo1WFYE9UK7985Oy77+zaNSKdu
// ZbBWN877w5AMdmswrC6HcDCXY0Sb3Noadfl9VcDqD69hq0vWPqAomrbjyyTUQCY3
// ru4kYaW0u8509KHlpN6ixQWmGAmVhMWtf0g1kPpzJ9HihRtAYUp5Jj4=
// -----END CERTIFICATE-----
// `
// 	defaultKey string = `-----BEGIN RSA PRIVATE KEY-----
// MIIEpgIBAAKCAQEAxs3bJLRtgxokBLe3HtbFpXEnNUDW6S3EXpnKxsSSsNiXlmGO
// NkeS3vrprS1f8ctPmSAOO4hxE49CBRWI1nYsZs+f8h555yW8/Liop25N3k5mkesv
// hMEgKYBY1xWI0YIn+MD5NKp5IB2iPkyV59nWwZ6b9HF9+GlCsGgmv6odFxGdp6po
// 43qMMZqqQ+HrSAp2jCnSYNmfnWv2BvBMRZ8GKczUvUHX7owMRyew6DIT2Z8nP7Ap
// mgavl3gGWzB7Vhbr/9uJQPysiQZghEBqdsfbZ/h5jPPUkDo9cjsDqmQfO/q4xDYa
// fO64ITA+Lwfd/zM5OPLQtS2Ja+3C6AYdtrbJEQIDAQABAoIBAQCMQh4TFkyRCzdQ
// MME8O7Bz2ZIc6yL0njqFt6EtfPA1XooMKcWom/SN5p5IdNPVBmihEtGXxNpqP08H
// wTqqe/M1kdQ5gLDmmGRuNGWgwpyjc9K/rhr3YT2sqgWDsYi2r0o+IP9w3bjZJK8b
// nvLAAZuXPKyw2AVU5gaL6N81p/IgHCoQ6GAkE19Bk2EK/vRoSKtmZsmsUY3RrezC
// HTSX4R4it2eMXBAxEF6stPK0tkv2BvOItoe5BGfWnd4VG2okVcHFkRPiaIiz60iy
// 02m6hei2dTKRe/GxaNNDNW8jNqTyJ4ZbUK8MeFVyCmFe+Zu8/LLF6bffj46HE00u
// yWovzFMxAoGBANq5gT27iGukc2MgXDc/yLKcwmXTU7hGH7TRBCu11Ms9fgInCsrz
// x9SRhI5KvysOVe80uPdtyoMx9+I/hzDDNBj0IrIXlO3tpgs26dqUN20CqRbepGwA
// aDXxy2D2lD4EHm1pDHU5SXngUECO1fyb9ErG4qeIdE4cfQ8h6ZhRblQNAoGBAOiv
// QvVNvfEm7Qz1BnCuwBTJfkScTJqLuel525c5PIj68w/B6D/cbYaKXr5kSFKroht9
// 8hr4lSHawLCAiBHc4mzXmyI1enxTH1+Sck2nzLxOWCqhExzmpNoKLI0T+Xhy0XH1
// dBQuD7QBdWsP4Y+shBdw/ehVPRqmwqY94Lgr5HQVAoGBAKWNhaJ5QK/hIKlmBAaZ
// k8qF1qqGAzdWdIdDMbn3/mH7YFY2wPeO/7EIl+Gv9/SZ/Dd7m4lEo+UbvDmWxjgF
// eHhuyZgtOz/AAk84uFcGmtE7E0tJKADLahVyt/LjkJ9ENNexjIlp3BCQ1Y2Xz6ZN
// UOIMmeAe65F4BLygeZQeBrk9AoGBAOPyxmrgBUMY+kOmSu/bEkuK9Ysrf5QrbC8A
// 9RHZvacICVQXh3oAbL/QEG7+eSecAsxh/utTOW4YCose765oMN2l/tFtiJgBKowL
// QLU4vMaBDbh9Yeb/QOJl8y0mM1A/U1YLuvMGCNY0U55VyYhh3mnEhMm1r43LbodD
// uUFTppPdAoGBAMHfXeOBXNGaCJf9wAF+qkfTG17z+rplO1ny9vX8p31i3F3wMJG0
// rDkznuYCa6PqBeav2UjbsfeqkynBggKM0wqMUcrSSCzKJEpaOjdaq1fw92Wf4tgq
// aJWMolGAClXedrb1jV2zZgl9xwi8kG1Y9EL4uVuCz2k03dFGuznMTW2v
// -----END RSA PRIVATE KEY-----
// `
// )

type Drone struct {
	commands    []icarus.Cmd
	name        string
	launch      int // Seconds before launch
	vehID       uint32
	finalLinger int
	finalPoint  Waypoint
	landPoint   Waypoint
	landVel     float32
	active      bool
}

type Waypoint struct {
	alt float32
	lat float64
	lon float64
}

type Command struct {
	gps    Waypoint
	vel    float32
	linger int
}

const (
	LAND   = 0
	GOTO   = 1
	LINGER = 2
	FIRE   = 3
)

var m = sync.Mutex{}

func main() {
	var query icarus.QueryPackage

	if len(os.Args) == 1 {
		query = icarus.NewQuery("10.59.144.32", "179")
	} else if len(os.Args) == 2 {
		query = icarus.NewQuery(os.Args[1], "179")
	} else {
		fmt.Println("Too many arguments")
		os.Exit(1)
	}

	query = icarus.NewQuery("10.59.144.32", "179")
	resp, ok := query.Authenticate("valinar", "thx4leakingThePassword@Valinar")
	if !ok {
		fmt.Println("Unable to authenticate to IcarusServer:", resp)
	}

	// start := false // MAKE THIS READ FILE
	// for !start {
	// 	time.Sleep(10 * time.Second)
	// 	fmt.Println("Hour:", time.Now().Hour(), "Minute:", time.Now().Minute())
	// 	if time.Now().Hour() == 2 && time.Now().Minute() == 24 {
	// 		start = true
	// 	}
	// }

	// openFile, err := os.Open("assets.csv") // IF IT NEEDS TO ADD VEHICLES
	// if err != nil {
	// 	log.Fatal("Unable to open CSV:", err.Error())
	// }

	// reader := csv.NewReader(openFile)
	// reader.Comment = '#'
	// reader.Read()
	// for {
	// 	record, err := reader.Read()
	// 	if err == io.EOF {
	// 		break
	// 	}
	// 	if err != nil {
	// 		log.Fatal("Error reading CSV:", err.Error())
	// 	}

	// 	secMode, _ := strconv.Atoi(record[6])
	// 	secMap := make([]string, 8)
	// 	secMap[0] = ""
	// 	secMap[1] = record[7]
	// 	secMap[2] = record[8]
	// 	secMap[3] = record[9]
	// 	secMap[4] = record[10]
	// 	secMap[5] = record[11]
	// 	secMap[6] = record[12]
	// 	secMap[7] = record[13]

	// 	// Add new vehicle to IcarusServer
	// 	addSeq := query.AddNewVehicle(record[2], record[3], record[1], record[4], secMode, secMap, []byte(defaultCert), []byte(defaultKey), 1, icarus.DefaultC3poTime, icarus.DefaultDaedalusTime)
	// 	responseChan, _ := query.Execute()
	// 	response := <-responseChan
	// 	fmt.Println(response.Get(addSeq))
	// }
	// fmt.Println("All vehicles added.")

	openFile, err := os.Open("routes.csv")
	if err != nil {
		log.Fatal("Unable to open CSV:", err.Error())
	}

	var drone [100]Drone
	var vel float32
	var alt float32
	var linger int

	reader := csv.NewReader(openFile)
	reader.Comment = '#'
	reader.Read()

	for i := 0; i < 100; i++ {

		record, err := reader.Read()
		if err == io.EOF {
			break
		}
		if err != nil {
			log.Fatal("Error reading CSV:", err.Error())
		}

		for j, value := range record {

			if value == "" {
				continue
			}

			if j == 0 {
				drone[i].name = value

				continue
			}

			if j == 1 {
				if value == "" {
					drone[i].launch = 0
				} else {
					drone[i].launch, _ = strconv.Atoi(value)
				}
				continue
			}

			if (j-2)%5 == 0 && record[j] != "" && record[j+1] != "" {

				// Has at least one waypoint
				drone[i].active = true

				// Altitude
				if record[j+2] != "" {
					flt64, _ := strconv.ParseFloat(record[j+2], 32)
					alt = float32(flt64)
				} else {
					alt = float32(1000 + i*10)
				}

				// Velocity
				if record[j+3] != "" {
					flt64, _ := strconv.ParseFloat(record[j+3], 32)
					vel = float32(flt64)
				} else {
					switch s := drone[i].name; s[0] {
					case 'G':
						vel = 165
					case 'K':
						vel = 120
					case 'A':
						vel = 90
					}
				}

				lat, _ := strconv.ParseFloat(record[j], 64)
				lon, _ := strconv.ParseFloat(record[j+1], 64)

				// Action

				if record[j+4] == "LAND" {
					drone[i].landPoint.alt = alt
					drone[i].landPoint.lat = lat
					drone[i].landPoint.lon = lon
					drone[i].landVel = vel
					fmt.Println("Added", drone[i].name, "waypoint to land at", lat, alt, lon, "at speed", vel)
					break
				}

				// Set final point
				drone[i].finalPoint.alt = alt
				drone[i].finalPoint.lat = lat
				drone[i].finalPoint.lon = lon
				drone[i].finalLinger = linger

				if record[j+4] != "" {
					linger, _ = strconv.Atoi(record[j+4])
					drone[i].commands = icarus.AddCmd(drone[i].commands, icarus.LOITER, lat, lon, alt, vel, 0, uint32(linger), 0)
					fmt.Println("Added", drone[i].name, "waypoint to", lat, alt, lon, "at speed", vel, "and linger for", linger, "seconds")
				} else {
					linger = 0
					drone[i].commands = icarus.AddCmd(drone[i].commands, icarus.GOTO, lat, lon, alt, vel, 0, uint32(linger), 0)
					fmt.Println("Added", drone[i].name, "waypoint to", lat, alt, lon, "at speed", vel)
				}
			}
		}
	}

	// Get active IDs
	statSeq := query.GetAllVehicleStatus()
	responseChan, _ := query.Execute()
	response := <-responseChan
	statusResponse, _ := response.Get(statSeq)

	for _, v := range statusResponse.Vehicles {
		for i := 0; i < 100; i++ {
			if drone[i].active && drone[i].name == v.VehicleCallsign {
				drone[i].vehID = v.VehicleId
				fmt.Println(v.VehicleCallsign, "gets ID", drone[i].vehID)

				if drone[i].active && drone[i].commands == nil {
					drone[i].finalPoint.alt = v.Telem.Altitude
					drone[i].finalPoint.lat = v.Telem.Latitude
					drone[i].finalPoint.lon = v.Telem.Longitude
					drone[i].finalLinger = 0
				}
				break
			}
		}
	}

	for i := 0; i < 100; i++ {
		if drone[i].active {
			go func(drone Drone) {
				fmt.Printf("Sending drone %s after %d seconds\n", drone.name, drone.launch)
				time.Sleep(time.Duration(drone.launch) * time.Second)
				fmt.Printf("Sending drone %s now\n", drone.name)

				m.Lock()
				launchSeq := query.SetNavMode(int(drone.vehID), icarus.NAVIGATION)
				responseChan, _ = query.Execute()
				response := <-responseChan
				_, ok = response.Get(launchSeq)
				if !ok {
					fmt.Println("Error:", response)
				}

				if drone.commands == nil {
					drone.commands = icarus.AddCmd(nil, icarus.GOTO, drone.finalPoint.lat, drone.finalPoint.lon, drone.finalPoint.alt+150, drone.landVel, 0, 0, 0)
				}

				gotoSeq := query.Goto(int(drone.vehID), drone.commands)
				responseChan, _ = query.Execute()
				response = <-responseChan
				_, ok = response.Get(gotoSeq)
				if !ok {
					fmt.Println("Error:", response)
				}

				query.ClearQueries()
				m.Unlock()

				// Check in range of the final point
				var inRange bool = false
				for !inRange {
					m.Lock()
					statSeq := query.GetVehicleStatus(int(drone.vehID))
					responseChan, _ := query.Execute()
					response := <-responseChan
					statusResponse, ok := response.Get(statSeq)
					if !ok {
						fmt.Println("Error:", response)
					}
					v := statusResponse.Vehicles[0]
					latDist := math.Pow(drone.finalPoint.lat-v.Telem.Latitude, 2)
					lonDist := math.Pow(drone.finalPoint.lon-v.Telem.Longitude, 2)
					altDist := math.Pow(float64(drone.finalPoint.alt-v.Telem.Altitude), 2)
					distance := math.Sqrt(latDist+lonDist+altDist) * 50000

					query.ClearQueries()
					m.Unlock()

					//Test this
					if distance > 2000 {
						time.Sleep(10 * time.Second)
					} else if distance > 1000 {
						time.Sleep(5 * time.Second)
					} else if distance > 200 {
						time.Sleep(100 * time.Millisecond)
					} else {
						inRange = true
					}

				}

				inRange = false
				// Sleep if supposed to linger at final point
				time.Sleep(time.Duration(drone.finalLinger) * time.Second)

				m.Lock()

				// Go to land point
				homeCmd := icarus.AddCmd(nil, icarus.GOTO, drone.landPoint.lat, drone.landPoint.lon, drone.landPoint.alt, drone.landVel, 0, 0, 0)
				gotoSeq = query.Goto(int(drone.vehID), homeCmd)
				responseChan, _ = query.Execute()
				response = <-responseChan
				_, ok = response.Get(gotoSeq)
				if !ok {
					fmt.Println("Error:", response)
				}

				query.ClearQueries()
				m.Unlock()

				// Check in range of land point
				for !inRange {
					m.Lock()
					statSeq := query.GetVehicleStatus(int(drone.vehID))
					responseChan, _ := query.Execute()
					response := <-responseChan
					statusResponse, ok := response.Get(statSeq)
					if !ok {
						fmt.Println("Error:", response)
					}
					v := statusResponse.Vehicles[0]
					latDist := math.Pow(drone.landPoint.lat-v.Telem.Latitude, 2)
					lonDist := math.Pow(drone.landPoint.lon-v.Telem.Longitude, 2)
					altDist := math.Pow(float64(drone.landPoint.alt-v.Telem.Altitude), 2)
					distance := math.Sqrt(latDist+lonDist+altDist) * 50000

					query.ClearQueries()
					m.Unlock()

					if distance > 2000 {
						time.Sleep(10 * time.Second)
					} else if distance > 1000 {
						m.Lock()
						homeCmd := icarus.AddCmd(nil, icarus.GOTO, drone.landPoint.lat, drone.landPoint.lon, drone.landPoint.alt, 90, 0, 0, 0)
						gotoSeq = query.Goto(int(drone.vehID), homeCmd)
						responseChan, _ = query.Execute()
						response = <-responseChan
						_, ok = response.Get(gotoSeq)
						if !ok {
							fmt.Println("Error:", response)
						}
						query.ClearQueries()
						m.Unlock()
						time.Sleep(5 * time.Second)
					} else if distance > 500 {
						m.Lock()
						homeCmd := icarus.AddCmd(nil, icarus.GOTO, drone.landPoint.lat, drone.landPoint.lon, drone.landPoint.alt, 50, 0, 0, 0)
						gotoSeq = query.Goto(int(drone.vehID), homeCmd)
						responseChan, _ = query.Execute()
						response = <-responseChan
						_, ok = response.Get(gotoSeq)
						if !ok {
							fmt.Println("Error:", response)
						}
						query.ClearQueries()
						m.Unlock()
						time.Sleep(1 * time.Second)
					} else if distance > 20 {
						m.Lock()
						homeCmd := icarus.AddCmd(nil, icarus.GOTO, drone.landPoint.lat, drone.landPoint.lon, drone.landPoint.alt, 20, 0, 0, 0)
						gotoSeq = query.Goto(int(drone.vehID), homeCmd)
						responseChan, _ = query.Execute()
						response = <-responseChan
						_, ok = response.Get(gotoSeq)
						if !ok {
							fmt.Println("Error:", response)
						}
						query.ClearQueries()
						m.Unlock()
						time.Sleep(100 * time.Millisecond)
					} else {
						inRange = true
					}
				}

				// Land
				m.Lock()
				landSeq := query.SetNavMode(int(drone.vehID), icarus.LAND_NOW)
				responseChan, _ = query.Execute()
				response = <-responseChan
				_, ok = response.Get(landSeq)
				if !ok {
					fmt.Println("No response")
				}

				query.ClearQueries()
				m.Unlock()
				fmt.Print((time.Now()).Format("15:04:05"), " ")
				fmt.Printf("Landing vehicle %d.\n", drone.vehID)

			}(drone[i])
		}
	}
	time.Sleep(120 * time.Minute)
}
