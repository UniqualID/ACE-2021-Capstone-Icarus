import subprocess
import time


p = subprocess.Popen(["./test"],
                     shell=True,
                     stdin=subprocess.PIPE,
                     stdout=subprocess.PIPE
                     )


time.sleep(1)
stdout, _ = p.communicate()
print(repr(stdout))

print(stdout.decode())