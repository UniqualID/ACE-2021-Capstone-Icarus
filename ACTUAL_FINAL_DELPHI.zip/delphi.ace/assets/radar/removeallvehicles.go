//removeVehicle.go
//This file contains an example of removing a vehicle from Icarus Server
package main

import (
	"fmt"
	"os"

	icarus "git.ironzone.ace/icarus/icarusClient"
)

func main() {

	var query icarus.QueryPackage

	if len(os.Args) == 1 {
		query = icarus.NewQuery("10.59.144.32", "179")
	} else if len(os.Args) == 2 {
		query = icarus.NewQuery(os.Args[1], "179")
	} else {
		fmt.Println("Too many arguments")
		os.Exit(1)
	}

	resp, ok := query.Authenticate("valinar", "thx4leakingThePassword@Valinar")
	if !ok {
		fmt.Println("Unable to authenticate to IcarusServer:", resp)
	}

	statSeq := query.GetAllVehicleStatus()
	responseChan, _ := query.Execute()
	response := <-responseChan
	statusResponse, ok := response.Get(statSeq)
	if !ok {
		fmt.Println("No response")
	}

	for _, v := range statusResponse.Vehicles {
		removeSeq := query.RemoveVehicle(int(v.VehicleId))
		responseChan2, _ := query.Execute()
		response = <-responseChan2
		_, ok = response.Get(removeSeq)
		if !ok {
			fmt.Println("No response")
		}
	}
	fmt.Println("All vehicles removed.")
}
