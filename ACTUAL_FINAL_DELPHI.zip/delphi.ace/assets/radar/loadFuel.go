package main

import (
	"fmt"
	"os"
	"strconv"

	icarus "git.ironzone.ace/icarus/icarusClient"
)

func main() {
	if len(os.Args) != 3 {
		fmt.Println("Missing/Invalid arguments")
		os.Exit(1)
	}

	var query = icarus.NewQuery("10.59.144.32", "179")
	resp, ok := query.Authenticate("valinar", "thx4leakingThePassword@Valinar")
	if !ok {
		fmt.Println("Unable to authenticate to IcarusServer:", resp)
	}

	vehID, _ := strconv.Atoi(os.Args[1])
	fuelAmt, _ := strconv.Atoi(os.Args[2])
	configs := icarus.AddPayloadConfig(nil, "Fuel", icarus.Fuel, fuelAmt, true)
	configSeq := query.ConfigurePayloads(vehID, configs)
	responseChan, _ := query.Execute()
	response := <-responseChan
	_, ok = response.Get(configSeq)
	if !ok {
		fmt.Println("No response")
		os.Exit(1)
	}
	fmt.Printf("Fueling vehicle %d.\n", vehID)
}
