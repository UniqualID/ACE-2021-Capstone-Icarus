import json

with open('lol.json.json') as f:
    data = json.load(f)

masterList = []

for a in data["infrastructure"]:
    masterList.append(a["id"])

for b in data['vehicles']:
    masterList.append(b["id"])

print(sorted(masterList))