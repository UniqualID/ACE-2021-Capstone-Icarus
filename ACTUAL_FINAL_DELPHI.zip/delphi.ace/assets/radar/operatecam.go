package main

import (
	"fmt"
	"os"
	"strconv"

	icarus "git.ironzone.ace/icarus/icarusClient"
)

func main() {
	if len(os.Args) != 2 {
		fmt.Println("Missing/Invalid arguments")
		os.Exit(1)
	}

	var query = icarus.NewQuery("10.59.144.32", "179")
	resp, ok := query.Authenticate("valinar", "thx4leakingThePassword@Valinar")
	if !ok {
		fmt.Println("Unable to authenticate to IcarusServer:", resp)
		os.Exit(1)
	}

	vehID, _ := strconv.Atoi(os.Args[1])

	configs := query.ExecutePayload(vehID, 4, 1, nil, 0)

	// configSeq := query.ConfigurePayloads(vehID, configs) // I AM NOT SURE WHAT THIS LINE DOES BUT I THINK IT RETURNS THE SAME THING AS EXECUTE PAYLOAD
	responseChan, _ := query.Execute()

	fmt.Printf("Vehicle %v taking picture...\n", vehID)
	response := <-responseChan

	configResponse, ok := response.Get(configs) // changed from configSeq
	if !ok {
		fmt.Println("picture not taken")
		os.Exit(1)
	}

	if configResponse.Ok {
		fmt.Printf("Vehicle %v picture complete\n\n", vehID)
		fmt.Printf("Images returned by vehicle %v: %v \n", vehID, configResponse.PayloadResponse.File)
	} else {
		fmt.Println("Error during picture taken: \n", configResponse.Message)
	}

	//Clear the refuel query from the queue
	query.ClearQueries()

}
